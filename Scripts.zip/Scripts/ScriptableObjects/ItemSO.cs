using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class ItemSO : ScriptableObject
{
    public enum ItemType
    {
        Wearable,
        Consumeable
    }

    public enum ArmorType
    {
        none,
        lightArmor,
        mediumArmor,
        heavyArmor
    }

    public enum WeaponType
    {
        none,
        lightWeapon,
        mediumWeapon,
        heavyWeapon,
        ranged
    }

    public bool isTwoHandled;

    public ItemType itemType;
    public ArmorType armorType;
    public WeaponType weaponType;
    
    public string itemName;
    public Sprite itemSprite;
    public GameObject itemPrefab;
    public int stackMax = 1;

    public int itemDamage;
    public int itemValue;
}
