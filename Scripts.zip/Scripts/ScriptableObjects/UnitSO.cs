using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class UnitSO : ScriptableObject
{

    public int basePhysicalDamage;
    public int baseSpellPower;



    public int baseBealth;
    public int physicalArmor;
    public int magicalArmor;


    public int baseStamina;
    public int baseMana;

    public int baseCarryCapasity;

    [Header("Physical Resistances")]
    public int basePiercingResistance;
    public int baseSlashingResistance;
    public int baseBluntResistance;

    [Header("Magical Resistances")]
    public int baseFireResistance;
    public int baseWaterResistance;
    public int baseAirResistance;
    public int baseEarthResistance;

    [Header("Stats")]
    public int baseStrength;
    public int baseDexterity;
    public int baseConstution;
    public int baseIntelligent;
    public int basePerception;
}
